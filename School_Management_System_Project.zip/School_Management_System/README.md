# School Management System

An offline-first, bilingual (English/Hindi) school records application for Android and Windows, built with Flutter and SQLite.

## Included modules
- Admin PIN login (default PIN: `1234`)
- Dashboard with student/staff/bus counts and fee/expense totals
- Student records
- Staff records
- Fee records
- Expense records
- School bus records
- Search, add, edit, view and delete records
- English/Hindi interface toggle
- Local SQLite database

## Important data behaviour
The database is stored locally on each device. Android and Windows do not synchronize records with each other. Use the same device for your records, or arrange a regular backup process before relying on this for official school records. Do not uninstall the app or clear its data without backing up the database.

## Run locally
Install Flutter SDK and Android Studio (for Android) or Visual Studio with the Desktop development with C++ workload (for Windows).

```bash
flutter pub get
flutter run
```

Enable Windows desktop support if needed:
```bash
flutter config --enable-windows-desktop
flutter create --platforms=windows .
flutter run -d windows
```

Enable Android support:
```bash
flutter doctor
flutter run
```

## Build
Android APK:
```bash
flutter build apk --release
```
Windows:
```bash
flutter build windows --release
```

## GitHub Actions
The repository includes workflows to build an Android APK and a Windows ZIP package. Windows builds require a Windows GitHub runner.
