import 'dart:convert';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (Platform.isWindows || Platform.isLinux || Platform.isMacOS) {
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
  }
  await SchoolDb.instance.init();
  runApp(const SchoolApp());
}

const orange = Color(0xFFF28C28);
const ink = Color(0xFF263238);
const bg = Color(0xFFF7F8FA);

class SchoolApp extends StatefulWidget {
  const SchoolApp({super.key});
  @override
  State<SchoolApp> createState() => _SchoolAppState();
}
class _SchoolAppState extends State<SchoolApp> {
  bool hindi = false;
  void toggleLanguage() => setState(() => hindi = !hindi);
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'School Management System',
    theme: ThemeData(
      useMaterial3: true, scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: orange, primary: orange, surface: Colors.white),
      appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: ink, elevation: 0, centerTitle: false),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18), side: const BorderSide(color: Color(0xFFEEF0F3)))),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: const Color(0xFFF7F8FA),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
    ),
    home: LoginScreen(hindi: hindi, onLanguage: toggleLanguage),
  );
}

String tr(bool hi, String en, String hn) => hi ? hn : en;

class Module {
  final String id, en, hi;
  final IconData icon;
  final List<String> fieldsEn, fieldsHi;
  const Module(this.id, this.en, this.hi, this.icon, this.fieldsEn, this.fieldsHi);
}
const modules = <Module>[
  Module('students','Students','छात्र',Icons.school,
    ['Student name','Admission number','Class / Section','Date of birth','Parent name','Parent phone','Address'],
    ['छात्र का नाम','प्रवेश संख्या','कक्षा / सेक्शन','जन्म तिथि','अभिभावक का नाम','अभिभावक का फोन','पता']),
  Module('staff','Staff','कर्मचारी',Icons.badge,
    ['Staff name','Employee ID','Role / Subject','Phone','Salary','Joining date','Address'],
    ['कर्मचारी का नाम','कर्मचारी आईडी','पद / विषय','फोन','वेतन','जॉइनिंग तिथि','पता']),
  Module('fees','Fees','फीस',Icons.currency_rupee,
    ['Student name','Admission number','Fee type','Amount','Paid amount','Due date','Payment date','Payment mode'],
    ['छात्र का नाम','प्रवेश संख्या','फीस का प्रकार','राशि','जमा राशि','अंतिम तिथि','भुगतान तिथि','भुगतान माध्यम']),
  Module('expenses','Expenses','खर्च',Icons.receipt_long,
    ['Expense title','Category','Amount','Date','Paid to','Payment mode','Notes'],
    ['खर्च का नाम','श्रेणी','राशि','तिथि','किसे भुगतान','भुगतान माध्यम','नोट्स']),
  Module('buses','School Buses','स्कूल बस',Icons.directions_bus,
    ['Bus number','Registration number','Driver name','Driver phone','Route','Capacity','Insurance / Permit expiry'],
    ['बस नंबर','रजिस्ट्रेशन नंबर','ड्राइवर का नाम','ड्राइवर का फोन','रूट','क्षमता','बीमा / परमिट समाप्ति']),
];

class SchoolDb {
  SchoolDb._();
  static final instance = SchoolDb._();
  Database? _db;
  Database get db => _db!;
  Future<void> init() async {
    if (_db != null) return;
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'school_manager.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('''CREATE TABLE records(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          module TEXT NOT NULL,
          title TEXT NOT NULL,
          subtitle TEXT,
          amount REAL NOT NULL DEFAULT 0,
          paid REAL NOT NULL DEFAULT 0,
          payload TEXT NOT NULL,
          created_at TEXT NOT NULL
        )''');
        await db.execute('CREATE INDEX idx_records_module ON records(module)');
      });
  }
  Future<List<Map<String,dynamic>>> list(String module, {String query = ''}) async {
    final rows = await db.query('records', where: 'module=?', whereArgs: [module], orderBy: 'id DESC');
    if (query.trim().isEmpty) return rows;
    final q = query.toLowerCase();
    return rows.where((r) => ('${r['title']} ${r['subtitle']} ${r['payload']}').toLowerCase().contains(q)).toList();
  }
  Future<void> save({int? id, required String module, required Map<String,String> values}) async {
    final title = values.values.firstWhere((v) => v.trim().isNotEmpty, orElse: () => 'Record');
    final subtitle = values.values.skip(1).firstWhere((v) => v.trim().isNotEmpty, orElse: () => '');
    double number(String key) => double.tryParse(values[key] ?? '') ?? 0;
    final amount = module == 'fees' ? number('Amount') : module == 'expenses' ? number('Amount') : 0;
    final paid = module == 'fees' ? number('Paid amount') : 0;
    final data = {'module':module,'title':title,'subtitle':subtitle,'amount':amount,'paid':paid,'payload':jsonEncode(values),'created_at':DateTime.now().toIso8601String()};
    if (id == null) {
      await db.insert('records', data);
    } else {
      await db.update('records', data, where: 'id=?', whereArgs: [id]);
    }
  }
  Future<void> delete(int id) async => db.delete('records', where: 'id=?', whereArgs: [id]);
  Future<Map<String,double>> totals() async {
    final rows = await db.rawQuery('SELECT module, COUNT(*) count, SUM(amount) amount, SUM(paid) paid FROM records GROUP BY module');
    final result = <String,double>{};
    for (final r in rows) {
      result['${r['module']}_count'] = (r['count'] as num).toDouble();
      result['${r['module']}_amount'] = (r['amount'] as num?)?.toDouble() ?? 0;
      result['${r['module']}_paid'] = (r['paid'] as num?)?.toDouble() ?? 0;
    }
    return result;
  }
}

class LoginScreen extends StatefulWidget {
  final bool hindi; final VoidCallback onLanguage;
  const LoginScreen({super.key, required this.hindi, required this.onLanguage});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final pin = TextEditingController();
  String error = '';
  Future<void> login() async {
    final prefs = await SharedPreferences.getInstance();
    final saved = prefs.getString('admin_pin') ?? '1234';
    if (pin.text == saved) {
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => HomeScreen(hindi: widget.hindi, onLanguage: widget.onLanguage)));
    } else { setState(() => error = tr(widget.hindi,'Incorrect PIN. Try again.','गलत PIN। फिर प्रयास करें।')); }
  }
  @override Widget build(BuildContext context) => Scaffold(
    body: Center(child: SingleChildScrollView(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 420), child: Padding(
      padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Container(width:82,height:82,decoration: BoxDecoration(color: orange.withOpacity(.13),borderRadius: BorderRadius.circular(24)),child: const Icon(Icons.school,color: orange,size:44)),
        const SizedBox(height:22),
        Text(tr(widget.hindi,'School Manager','स्कूल मैनेजर'),style: const TextStyle(fontSize:28,fontWeight:FontWeight.w800,color:ink)),
        const SizedBox(height:6),
        Text(tr(widget.hindi,'Offline School Management System','ऑफलाइन स्कूल प्रबंधन सिस्टम'),style: const TextStyle(color:Colors.black54)),
        const SizedBox(height:32),
        TextField(controller: pin, obscureText:true, keyboardType:TextInputType.number, maxLength:8, decoration: InputDecoration(labelText:tr(widget.hindi,'Admin PIN','एडमिन PIN'),prefixIcon:const Icon(Icons.lock),counterText:''), onSubmitted: (_) => login()),
        if(error.isNotEmpty) Padding(padding:const EdgeInsets.only(top:8),child:Text(error,style:const TextStyle(color:Colors.red))),
        const SizedBox(height:16),
        SizedBox(width:double.infinity,height:50,child:FilledButton(onPressed:login,style:FilledButton.styleFrom(backgroundColor:orange),child:Text(tr(widget.hindi,'LOGIN','लॉगिन')))),
        const SizedBox(height:12),
        TextButton(onPressed:widget.onLanguage,child:Text(widget.hindi?'Switch to English':'हिंदी में देखें')),
        const SizedBox(height:18),
        Text(tr(widget.hindi,'Default PIN: 1234. Change it after your first login.','डिफ़ॉल्ट PIN: 1234। पहली बार लॉगिन के बाद इसे बदलें।'),textAlign:TextAlign.center,style:const TextStyle(color:Colors.black45,fontSize:12)),
      ]),
    )))),
  );
}

class HomeScreen extends StatefulWidget {
  final bool hindi; final VoidCallback onLanguage;
  const HomeScreen({super.key,required this.hindi,required this.onLanguage});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  int tab=0; Map<String,double> stats={}; bool loading=true; late bool hi;
  @override void initState(){super.initState();hi=widget.hindi;refresh();}
  Future<void> refresh() async { final s=await SchoolDb.instance.totals(); if(mounted)setState(() { stats=s; loading=false; }); }
  @override Widget build(BuildContext context) {
    final hi=this.hi;
    return Scaffold(
      appBar: AppBar(
        title: Row(children:[Container(width:38,height:38,decoration:BoxDecoration(color:orange.withOpacity(.14),borderRadius:BorderRadius.circular(12)),child:const Icon(Icons.school,color:orange)),const SizedBox(width:10),Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('SCHOOL MANAGER',style:TextStyle(fontSize:15,fontWeight:FontWeight.w800,letterSpacing:.5)),Text(tr(hi,'Admin workspace','एडमिन पैनल'),style:const TextStyle(fontSize:11,color:Colors.black45))])]),
        actions:[IconButton(tooltip:tr(hi,'Language','भाषा'),onPressed:()=>setState(()=>hi=!hi),icon:const Icon(Icons.translate)),PopupMenuButton<String>(onSelected:(v){if(v=='pin')changePin();if(v=='refresh')refresh();},itemBuilder:(_)=>[PopupMenuItem(value:'pin',child:Text(tr(hi,'Change admin PIN','एडमिन PIN बदलें'))),PopupMenuItem(value:'refresh',child:Text(tr(hi,'Refresh dashboard','डैशबोर्ड रिफ्रेश करें')))])],
      ),
      body: loading ? const Center(child:CircularProgressIndicator(color:orange)) : tab==0 ? dashboard() : ModuleScreen(module:modules[tab-1],hindi:hi,onChanged:refresh),
      bottomNavigationBar: NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),backgroundColor:Colors.white,indicatorColor:orange.withOpacity(.14),labelBehavior:NavigationDestinationLabelBehavior.onlyShowSelected,
        destinations:[NavigationDestination(icon:const Icon(Icons.dashboard_outlined),selectedIcon:const Icon(Icons.dashboard,color:orange),label:tr(hi,'Home','होम')),for(final m in modules) NavigationDestination(icon:Icon(m.icon),label:hi?m.hi:m.en)]),
    );
  }
  Widget dashboard(){
    final hi=widget.hindi; final fee=stats['fees_amount']??0; final paid=stats['fees_paid']??0; final exp=stats['expenses_amount']??0;
    return RefreshIndicator(color:orange,onRefresh:refresh,child:ListView(padding:const EdgeInsets.all(18),children:[
      Container(padding:const EdgeInsets.all(20),decoration:BoxDecoration(gradient:const LinearGradient(colors:[Color(0xFFFFA94D),Color(0xFFF28C28)]),borderRadius:BorderRadius.circular(22)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
        Text(tr(hi,'Good day, Administrator','नमस्ते, एडमिन'),style:const TextStyle(color:Colors.white70,fontSize:13)),
        const SizedBox(height:8),Text(tr(hi,'Your school at a glance','आपके स्कूल का सारांश'),style:const TextStyle(color:Colors.white,fontSize:22,fontWeight:FontWeight.w800)),
        const SizedBox(height:8),Text(DateFormat('EEEE, dd MMM yyyy').format(DateTime.now()),style:const TextStyle(color:Colors.white)),
      ])),
      const SizedBox(height:20),
      Text(tr(hi,'OVERVIEW','मुख्य जानकारी'),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12,letterSpacing:1,color:Colors.black54)),
      const SizedBox(height:12),
      GridView.count(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),crossAxisCount:2,crossAxisSpacing:12,mainAxisSpacing:12,childAspectRatio:1.55,children:[
        statCard(tr(hi,'Students','छात्र'),(stats['students_count']??0).toInt().toString(),Icons.school),
        statCard(tr(hi,'Staff','कर्मचारी'),(stats['staff_count']??0).toInt().toString(),Icons.people_alt),
        statCard(tr(hi,'Fee records','फीस रिकॉर्ड'),(stats['fees_count']??0).toInt().toString(),Icons.currency_rupee),
        statCard(tr(hi,'School buses','स्कूल बस'),(stats['buses_count']??0).toInt().toString(),Icons.directions_bus),
      ]),
      const SizedBox(height:18),
      Text(tr(hi,'FINANCIAL SUMMARY','वित्तीय सारांश'),style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12,letterSpacing:1,color:Colors.black54)),
      const SizedBox(height:12),
      Row(children:[
        Expanded(child:moneyCard(tr(hi,'Fees collected','जमा फीस'),paid,Icons.payments)),
        const SizedBox(width:10),Expanded(child:moneyCard(tr(hi,'Expenses','कुल खर्च'),exp,Icons.receipt_long)),
      ]),
      const SizedBox(height:10),
      moneyCard(tr(hi,'Total fee amount','कुल फीस राशि'),fee,Icons.account_balance_wallet,wide:true),
      const SizedBox(height:18),
      Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(16),border:Border.all(color:const Color(0xFFEEF0F3))),child:Row(children:[const Icon(Icons.offline_bolt,color:orange),const SizedBox(width:10),Expanded(child:Text(tr(hi,'Offline mode is active. Data stays on this device.','ऑफलाइन मोड चालू है। डेटा इसी डिवाइस में रहेगा।'),style:const TextStyle(fontSize:12,color:Colors.black54)))])),
    ]));
  }
  Widget statCard(String title,String value,IconData icon)=>Container(padding:const EdgeInsets.all(14),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17),border:Border.all(color:const Color(0xFFEEF0F3))),child:Column(crossAxisAlignment:CrossAxisAlignment.start,mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[Icon(icon,color:orange,size:22),Text(value,style:const TextStyle(fontSize:24,fontWeight:FontWeight.w800,color:ink)),Text(title,style:const TextStyle(color:Colors.black54,fontSize:12))]));
  Widget moneyCard(String title,double value,IconData icon,{bool wide=false})=>Container(padding:const EdgeInsets.all(15),decoration:BoxDecoration(color:Colors.white,borderRadius:BorderRadius.circular(17),border:Border.all(color:const Color(0xFFEEF0F3))),child:Row(children:[Icon(icon,color:orange),const SizedBox(width:10),Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(title,style:const TextStyle(fontSize:11,color:Colors.black54)),Text('₹${value.toStringAsFixed(2)}',style:TextStyle(fontSize:wide?20:17,fontWeight:FontWeight.w800,color:ink))]))]));
  Future<void> changePin() async {
    final old=TextEditingController(), next=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(tr(hi,'Change admin PIN','एडमिन PIN बदलें')),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:old,obscureText:true,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:tr(hi,'Current PIN','मौजूदा PIN'))),const SizedBox(height:10),TextField(controller:next,obscureText:true,keyboardType:TextInputType.number,decoration:InputDecoration(labelText:tr(hi,'New PIN (4-8 digits)','नया PIN (4-8 अंक)')))]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(tr(hi,'Cancel','रद्द करें'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:Text(tr(hi,'Save','सेव करें')))]));
    if(ok!=true)return;
    final prefs=await SharedPreferences.getInstance();
    if(old.text==(prefs.getString('admin_pin')??'1234') && RegExp(r'^\d{4,8}$').hasMatch(next.text)){await prefs.setString('admin_pin',next.text);if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(tr(hi,'PIN updated.','PIN अपडेट हो गया।'))));}
    else if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(tr(hi,'Current PIN or new PIN is invalid.','मौजूदा या नया PIN गलत है।'))));
  }
}

class ModuleScreen extends StatefulWidget {
  final Module module; final bool hindi; final VoidCallback onChanged;
  const ModuleScreen({super.key,required this.module,required this.hindi,required this.onChanged});
  @override State<ModuleScreen> createState()=>_ModuleScreenState();
}
class _ModuleScreenState extends State<ModuleScreen> {
  final search=TextEditingController(); List<Map<String,dynamic>> rows=[];
  @override void initState(){super.initState();load();}
  Future<void> load() async {final r=await SchoolDb.instance.list(widget.module.id,query:search.text);if(mounted)setState(()=>rows=r);}
  @override Widget build(BuildContext context){
    final m=widget.module;final hi=widget.hindi;
    return Column(children:[
      Padding(padding:const EdgeInsets.fromLTRB(16,16,16,8),child:Row(children:[Expanded(child:Text(hi?m.hi:m.en,style:const TextStyle(fontSize:23,fontWeight:FontWeight.w800,color:ink))),FilledButton.icon(onPressed:()=>edit(),icon:const Icon(Icons.add,size:18),label:Text(tr(hi,'Add new','नया जोड़ें')),style:FilledButton.styleFrom(backgroundColor:orange))])),
      Padding(padding:const EdgeInsets.fromLTRB(16,8,16,12),child:TextField(controller:search,onChanged:(_)=>load(),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:tr(hi,'Search records...','रिकॉर्ड खोजें...'),suffixIcon:IconButton(onPressed:(){search.clear();load();},icon:const Icon(Icons.close))))),
      Expanded(child:rows.isEmpty?Center(child:Column(mainAxisSize:MainAxisSize.min,children:[Icon(m.icon,size:46,color:orange.withOpacity(.55)),const SizedBox(height:12),Text(tr(hi,'No records yet','अभी कोई रिकॉर्ड नहीं है'),style:const TextStyle(color:Colors.black54)),const SizedBox(height:8),Text(tr(hi,'Tap Add new to create your first record.','पहला रिकॉर्ड बनाने के लिए नया जोड़ें दबाएं।'),style:const TextStyle(fontSize:12,color:Colors.black38))])):ListView.separated(padding:const EdgeInsets.fromLTRB(16,4,16,20),itemCount:rows.length,separatorBuilder:(_,__)=>const SizedBox(height:8),itemBuilder:(ctx,i){
        final r=rows[i];Map<String,dynamic> data={};try{data=jsonDecode(r['payload'] as String);}catch(_){}
        final subtitle=(r['subtitle']??'').toString();
        return Card(child:ListTile(contentPadding:const EdgeInsets.symmetric(horizontal:14,vertical:6),leading:Container(width:42,height:42,decoration:BoxDecoration(color:orange.withOpacity(.12),borderRadius:BorderRadius.circular(13)),child:Icon(m.icon,color:orange)),title:Text((r['title']??'').toString(),style:const TextStyle(fontWeight:FontWeight.w700)),subtitle:Text(subtitle.isEmpty?tr(hi,'No additional details','अतिरिक्त जानकारी नहीं'):subtitle,maxLines:1,overflow:TextOverflow.ellipsis),trailing:PopupMenuButton<String>(onSelected:(v){if(v=='edit')edit(row:r,data:data);if(v=='delete')confirmDelete(r);},itemBuilder:(_)=>[PopupMenuItem(value:'edit',child:Text(tr(hi,'Edit','बदलें'))),PopupMenuItem(value:'delete',child:Text(tr(hi,'Delete','हटाएं')))]),onTap:()=>showDetails(data)));
      })),
    ]);
  }
  Future<void> edit({Map<String,dynamic>? row,Map<String,dynamic>? data}) async {
    final values=<String,TextEditingController>{};
    for(final f in widget.module.fieldsEn){values[f]=TextEditingController(text:(data?[f]??'').toString());}
    final result=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(
      title:Text(row==null?tr(widget.hindi,'Add record','रिकॉर्ड जोड़ें'):tr(widget.hindi,'Edit record','रिकॉर्ड बदलें')),
      content:SizedBox(width:460,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[for(var i=0;i<widget.module.fieldsEn.length;i++) Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:values[widget.module.fieldsEn[i]],keyboardType:_numeric(widget.module.fieldsEn[i])?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,decoration:InputDecoration(labelText:widget.hindi?widget.module.fieldsHi[i]:widget.module.fieldsEn[i],hintText:_hint(widget.module.fieldsEn[i]))))]))),
      actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(tr(hi,'Cancel','रद्द करें'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:orange),child:Text(tr(widget.hindi,'Save record','रिकॉर्ड सेव करें')))]));
    if(result==true){final map={for(final e in values.entries)e.key:e.value.text.trim()};await SchoolDb.instance.save(id:row==null?null:row['id'] as int,module:widget.module.id,values:map);await load();widget.onChanged();}
    for(final c in values.values){c.dispose();}
  }
  bool _numeric(String f)=>['Amount','Paid amount','Salary','Capacity'].contains(f);
  String? _hint(String f)=>f.toLowerCase().contains('date')||f.toLowerCase().contains('expiry')?'DD-MM-YYYY':null;
  Future<void> confirmDelete(Map<String,dynamic> row) async {
    final yes=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:Text(tr(widget.hindi,'Delete record?','रिकॉर्ड हटाएं?')),content:Text(tr(widget.hindi,'This action cannot be undone.','यह कार्रवाई वापस नहीं होगी।')),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:Text(tr(hi,'Cancel','रद्द करें'))),FilledButton(onPressed:()=>Navigator.pop(ctx,true),style:FilledButton.styleFrom(backgroundColor:Colors.red),child:Text(tr(widget.hindi,'Delete','हटाएं')))]));
    if(yes==true){await SchoolDb.instance.delete(row['id'] as int);await load();widget.onChanged();}
  }
  void showDetails(Map<String,dynamic> data){showModalBottomSheet(context:context,showDragHandle:true,isScrollControlled:true,builder:(ctx)=>SafeArea(child:Padding(padding:const EdgeInsets.all(20),child:ListView(shrinkWrap:true,children:[Text(widget.hindi?widget.module.hi:widget.module.en,style:const TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:12),for(var i=0;i<widget.module.fieldsEn.length;i++)if((data[widget.module.fieldsEn[i]]??'').toString().isNotEmpty)Padding(padding:const EdgeInsets.symmetric(vertical:7),child:Row(crossAxisAlignment:CrossAxisAlignment.start,children:[SizedBox(width:130,child:Text(widget.hindi?widget.module.fieldsHi[i]:widget.module.fieldsEn[i],style:const TextStyle(color:Colors.black54,fontSize:12))),Expanded(child:Text(data[widget.module.fieldsEn[i]].toString(),style:const TextStyle(fontWeight:FontWeight.w600))) ]))]))));}
}
